from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import HouseholdModuleAccess, Module, User, UserModuleAccess
from app.models.enums import UserRole
from app.modules import AVAILABLE_MODULES, DEFAULT_ROLE_MODULES, MODULE_ADMIN, AppModule


class ModuleService:
    def ensure_catalog(self, session: Session) -> None:
        existing = set(session.scalars(select(Module.key)).all())
        for module in AVAILABLE_MODULES:
            if module.key in existing:
                continue
            session.add(Module(key=module.key, name=module.name, description=module.description, enabled=module.key != "family-tree"))
        session.flush()

    def list_effective_modules(self, session: Session, user: User) -> list[AppModule]:
        self.ensure_catalog(session)
        catalog = {module.key: module for module in AVAILABLE_MODULES}
        allowed_keys = set(DEFAULT_ROLE_MODULES.get(user.role, ()))

        enabled_catalog_keys = set(
            session.scalars(select(Module.key).where(Module.enabled.is_(True))).all()
        )
        allowed_keys &= enabled_catalog_keys

        household_overrides = {
            row.module_key: row.enabled
            for row in session.scalars(
                select(HouseholdModuleAccess).where(HouseholdModuleAccess.household_id == user.household_id).execution_options(populate_existing=True)
            ).all()
        }
        household_enabled_keys = set(enabled_catalog_keys)
        for key, enabled in household_overrides.items():
            if enabled and key in enabled_catalog_keys:
                allowed_keys.add(key)
            else:
                allowed_keys.discard(key)
                household_enabled_keys.discard(key)

        user_overrides = {
            row.module_key: row
            for row in session.scalars(select(UserModuleAccess).where(UserModuleAccess.user_id == user.id).execution_options(populate_existing=True)).all()
        }
        for key, override in user_overrides.items():
            if override.can_view and key in household_enabled_keys:
                allowed_keys.add(key)
            else:
                allowed_keys.discard(key)

        # Genealogy is deliberately opt-in, including missing-row and corrupt child grants.
        if not household_overrides.get("family-tree", False) or user.role == UserRole.CHILD:
            allowed_keys.discard("family-tree")
        return [module for module in AVAILABLE_MODULES if module.key in allowed_keys and module.key in catalog]

    def can_access_module(self, session: Session, user: User, module_key: str, *, manage: bool = False) -> bool:
        if module_key not in module_keys(self.list_effective_modules(session, user)):
            return False
        if not manage:
            return True
        override = session.get(UserModuleAccess, {"user_id": user.id, "module_key": module_key}, populate_existing=True)
        # Default role/household access remains fully usable. An explicit user override
        # is the only place that can intentionally reduce a user to view-only.
        return override is None or override.can_manage

    def list_household_user_access(self, session: Session, household_id: int) -> list[tuple[User, list[AppModule]]]:
        users = session.scalars(select(User).where(User.household_id == household_id).order_by(User.email)).all()
        return [(user, self.list_effective_modules(session, user)) for user in users]

    def list_household_access(self, session: Session, household_id: int) -> list[tuple[AppModule, bool]]:
        self.ensure_catalog(session)
        globally_enabled = set(session.scalars(select(Module.key).where(Module.enabled.is_(True))).all())
        overrides = {
            row.module_key: row.enabled
            for row in session.scalars(
                select(HouseholdModuleAccess).where(HouseholdModuleAccess.household_id == household_id)
            ).all()
        }
        return [
            (module, module.key in globally_enabled and overrides.get(module.key, module.key != "family-tree"))
            for module in AVAILABLE_MODULES
        ]

    def set_household_access(
        self,
        session: Session,
        *,
        household_id: int,
        module_key: str,
        enabled: bool,
    ) -> tuple[AppModule, bool]:
        self.ensure_catalog(session)
        module = next((item for item in AVAILABLE_MODULES if item.key == module_key), None)
        if module is None:
            raise ValueError("Unknown module key.")
        if module_key == MODULE_ADMIN and not enabled:
            raise ValueError("The admin module cannot be disabled for a household.")
        globally_enabled = session.scalar(select(Module.enabled).where(Module.key == module_key))
        if enabled and not globally_enabled:
            raise ValueError("This module is disabled globally and cannot be enabled for a household.")
        access = session.get(
            HouseholdModuleAccess,
            {"household_id": household_id, "module_key": module_key},
        )
        if access is None:
            access = HouseholdModuleAccess(
                household_id=household_id,
                module_key=module_key,
                enabled=enabled,
            )
            session.add(access)
        else:
            access.enabled = enabled
        session.flush()
        return module, bool(globally_enabled and enabled)

    def set_user_access(self, session: Session, target_user: User, module_key: str, can_view: bool, can_manage: bool = False) -> UserModuleAccess:
        self.ensure_catalog(session)
        if module_key not in {module.key for module in AVAILABLE_MODULES}:
            raise ValueError("Unknown module key.")
        if module_key == MODULE_ADMIN and (not can_view or not can_manage) and self._is_last_admin_manager(session, target_user):
            raise ValueError("Cannot remove admin module access from the last household admin.")
        access = session.get(UserModuleAccess, {"user_id": target_user.id, "module_key": module_key})
        if access is None:
            access = UserModuleAccess(user_id=target_user.id, module_key=module_key, can_view=can_view, can_manage=can_manage)
            session.add(access)
        else:
            access.can_view = can_view
            access.can_manage = can_manage
        session.flush()
        return access

    def _is_last_admin_manager(self, session: Session, target_user: User) -> bool:
        admin_users = session.scalars(
            select(User).where(
                User.household_id == target_user.household_id,
                User.role == UserRole.PARENT_ADMIN,
                User.active.is_(True),
            )
        ).all()
        admin_managers = [user for user in admin_users if self.can_access_module(session, user, MODULE_ADMIN, manage=True)]
        return len(admin_managers) == 1 and admin_managers[0].id == target_user.id


def module_keys(modules: list[AppModule]) -> list[str]:
    return [module.key for module in modules]
